<div id="nav_main">

    <h4>INSERT</h4>
    <ul>

        <li><a href="Reg.php">Account</a></li>
        <li><a href="events.php">Events</a></li>
        <li><a href="consumer_pro_up.php">Consumer Products</a></li>

        <li><a href="download_up.php">Download forms</a></li>
    </ul>

    <h4>EDIT</h4>
    <ul>

        <li><a href="balance_dec.php">Balance Decrement</a></li>
        


    </ul>

    <h4>DELETE</h4>
    <ul>

        <li><a href="del.php">Account</a></li>

    </ul>

    <h4>Complaint Cell</h4>
    <ul>

        <li><a href="complain_admin.php">Complaint Cell</a></li>

    </ul>




</div>