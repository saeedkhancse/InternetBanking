<?php include 'htmlHeader1.php'; ?>
<div id="container">
    <?php include 'Header.php'; ?>
    <div id="content_main">
        <? include 'news&events.php '; ?>
    </div>
    <?php include 'rightSidebar.php'; ?>
</div>
<?php include 'Footer.php'; ?>
