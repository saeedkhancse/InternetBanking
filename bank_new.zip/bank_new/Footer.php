<style type="text/css">
<!--
.style1 {
	color: #0000FF;
	font-size: 12px;
}
.style2 {color: #FF6600}
.style4 {color: #3333CC}
-->
</style>

<div id="footer">

    <div class="style1" id="copyright"><span class="style4">All Rights powered by</span> <span class="style2">Khan Saeed, leema Rani Dey &amp; Bipasha Habib </span></div>
    <ul id="nav_footer">
        <li><a href="index.php">Home</a> |</li>
        <li>&nbsp;<a href="contact.php">Contact</a> </li>
        
    </ul>

</div>
</body>
</html>