<style type="text/css">
<!--
.style1 {font-size: 36px}
-->
</style>
<div id="content_main">
    <h3 class="style1">Scotia Bank</h3>
    <div>
        <img src="images/savings_plus.jpg" width="700px;" height="200px;"/>
    </div>
    <br/>
    <p>
        Corporate Banking provides financial products & services reaching the country’s growing corporate base. With our expertise and dedication we, at EBL Corporate Banking, aim to provide the best possible services to our customers and with that in mind, we have proved ourselves to be one of the leading bank in helping clients to achieve success in every business endeavor they have. 
        In addition to traditional industries like RMG, Steel, Pharmaceuticals, Textiles, Ship Breaking & Trading sector; EBL has enhanced its footprints into Packaging, Food, Power, Construction, Aviation, Glassware, Edible Oil Refinery, Healthcare, Renewable Energy, Plastic Polymer, Telecommunications, Ocean-Going Vessel financing, Agri-Business (Poultry, Food Processing), etc. 
        Our expertise covers areas like Project financing, Trade Financing, Working Capital Financing, etc. Divided into 2 (two) Corporate Banking wings, one in Dhaka and the other in Chittagong, is an integrated & specialized area of the bank, which meets the diverse financial needs of the corporate customers by designing customized and structured solutions for their business.    </p>
</div>