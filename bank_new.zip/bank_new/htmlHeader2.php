<?php session_start();?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style2.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript">
    $(document).ready(function(){

        $('#register').validate();
    });
</script>
	

</head>
<body>