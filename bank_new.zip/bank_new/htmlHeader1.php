<?php session_start();?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript">
    $(document).ready(function(){

        $('#register').validate();
    });
</script>
	

</head>
<body>