<?php include 'htmlHeader.php';?>
<div id="container">
    <?php include 'Header.php'; ?>
    <?php include 'Content.php'; ?>
    <?php include 'rightSidebar.php'; ?>
</div>
<?php include 'Footer.php'; ?>
