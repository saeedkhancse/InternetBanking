<?php include 'htmlHeader.php';?>
<div id="container">
    <?php include 'Header.php'; ?>
    <div id="content_main">
        <h3>About Us</h3>
        <p><img src="images/imagres.jpg" width="600" height="250"/>
	
		<br/>
            MISSION:Scotia Bank engineers enterprise and creativity in business and industry with a commitment to social responsibility. "Profits alone" do not hold a central focus in the Bank's operation; because "man does not live by bread and butter alone".
            VISION: Scotia Bank dreams of better Bangladesh, where arts and letters, sports and athletics, music and entertainment, science and education, health and hygiene, clean and pollution free environment and above all a society based on morality and ethics make all our lives worth living. DBBL's essence and ethos rest on a cosmos of creativity and the marvel-magic of a charmed life that abounds with spirit of life and adventures that contributes towards human development.
            CORE_OBJECTIVES: scotia Bank believes in its uncompromising commitment to fulfill its customer needs and satisfaction and to become their first choice in banking. Taking cue from its pool esteemed clientele, scotia Bank intends to pave the way for a new era in banking that upholds and epitomizes its vaunted marquees "Your Trusted Partner"
        </p>
    </div>
    <?php include 'rightSidebar.php'; ?>
</div>
<?php include 'Footer.php'; ?>
