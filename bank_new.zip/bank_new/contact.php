<?php include 'htmlHeader.php';?>
<div id="container">
    <?php include 'Header.php'; ?>
    <div id="content_main">
        <h3>Contact Us</h3>
        
	
		<p>
           

EBL Head Office


Corporate Banking Office Dhaka


Corporate Banking - Uday Tower Office


Gulshan Cards Center












Jiban Bima Bhaban 
 10, Dilkusha C/A 
 Dhaka - 1000 
 Phone: 02-9556360


Jiban Bima Bhaban 
 10, Dilkusha C/A Dhaka 
 Phone: PABX-9556360, Tel: 02-9554830, 02-9565696


Uday Tower (1st Floor) 
 Plot: 57 & 57/A 
 Gulshan Avenue (South) 
 Dhaka -1212 
 Phone: 02 8834328-8833607 
 Fax: 02 8835420


Sabera Tower (5th ), House 42, Road-52 Gulshan North C/A, Dhaka-1212 
 Phone: 16230 or  +88 02 8332232  
 Fax: 02 9882316

 


 

        </p</p>
    </div>
    <?php include 'rightSidebar.php'; ?>
</div>
<?php include 'Footer.php'; ?>
